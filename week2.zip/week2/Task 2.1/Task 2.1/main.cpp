#include <iostream>
using namespace std;

class Circle {
private:
    float radius;
    float area;

public:
    Circle() {
        cout << "Enter radius of a circle = ";
        cin >> radius;
    }

    void calculateArea()
    {
        const float PI = 3.14159;
        area = PI * radius * radius;
    }

    void displayArea()
    const {
        cout << "is " << area << endl;
    }

    void compare_areas(const Circle & Secound_Circle)
    {
        cout << "The results of Comparing two Circles " << endl;
        cout << "First Circle Area "<<endl;
        displayArea();
        
        cout << "Secound Circle Area ";
        Secound_Circle.displayArea();

        if (area > Secound_Circle.area) {
            cout << "The first circle has a larger area" << endl;
        } else if (Secound_Circle.area > area) {
            cout << "The secound circle has a larger area" << endl;
        } else {
            cout << "Both circles have equal area" << endl;
        }
    }
};

int main() {
    Circle circle1, circle2;
    circle1.calculateArea();
    circle2.calculateArea();
    circle1.compare_areas(circle2);

    return 0;
}
