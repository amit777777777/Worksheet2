#include <iostream>
using namespace std;

class Student {
    private:
        string name;
        int subject1, subject2, subject3;
        float total, average;

    public:
        void get_student_details() {
            cout << "Enter Students name = ";
            cin >> name;

            cout << "Enter Subject 1 Marks = ";
            cin >> subject1;

            cout << "Enter Subject 2 Marks =";
            cin >> subject2;

            cout << "Enter Subject 3 Marks =";
            cin >> subject3;

            if (!isValidMarks()) {
                cout << "Invalid marks, Enter between between 0 and 100." << endl;
                get_student_details();
            }
        }

        bool isValidMarks() {
            if (subject1 < 0 || subject1 > 100 || subject2 < 0 || subject2 > 100 || subject3 < 0 || subject3 > 100) {
                return false;
            }
            return true;
        }
    
        void calculate_Marks() {
            total = subject1 + subject2 + subject3;
            average = total / 3;
        }

        string grade() {
            if (average >= 90) return "A";
            else if (average >= 80) return "B";
            else if (average >= 70) return "C";
            else if (average >= 60) return "D";
            else return "F";
        }

        void display() {
            cout << "Student Name: " << name << endl;
            cout << "Subject 1 Marks: " << subject1 << endl;
            cout << "Subject 2 Marks: " << subject2 << endl;
            cout << "Subject 3 Marks: " << subject3 << endl;
            
            calculate_Marks();
            cout << "Your Total marks is " << total << endl;
            cout << "Your Average marks is " << average << " Out of 100"<< endl;
            cout << "Your grade is " << grade() << endl;
            cout << "Congratulation. "<< endl;
        }
};

int main() {
    Student student;
    student.get_student_details();
    student.display();

    return 0;
}

