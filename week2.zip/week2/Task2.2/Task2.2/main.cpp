#include <iostream>
using namespace std;

class Over_load {
public:
    void findMax(int a, int b) {
        cout << "Enter two integer numbers:" << endl;
        cin >> a >> b;

        if (a > b) {
            cout << "a is the maximum number" << endl;
        } else if (b > a) {
            cout << "b is the maximum number" << endl;
        } else {
            cout << "Both numbers are equal" << endl;
        }
    }

    void findMax(float a, float b) {
        cout << "Enter two floating-point numbers:" << endl;
        cin >> a >> b;

        if (a > b) {
            cout << "a is the maximum number" << endl;
        } else if (b > a) {
            cout << "b is the maximum number" << endl;
        } else {
            cout << "Both numbers are equal" << endl;
        }
    }

    void findMax(int a, int b, int c) {
        cout << "Enter three integer numbers:" << endl;
        cin >> a >> b >> c;

        if (a > b && a > c) {
            cout << "a is the maximum number" << endl;
        } else if (b > a && b > c) {
            cout << "b is the maximum number" << endl;
        } else if (c > a && c > b) {
            cout << "c is the maximum number" << endl;
        } else {
            cout << "Some or all numbers are equal" << endl;
        }
    }

    void findMax(int a, float b) {
        cout << "Enter one integer and one floating-point number:" << endl;
        cin >> a >> b;

        if (a > b) {
            cout << "a is the maximum number" << endl;
        } else if (b > a) {
            cout << "b is the maximum number" << endl;
        } else {
            cout << "Both numbers are equal" << endl;
        }
    }
};

int main() {
    Over_load O1;
    O1.findMax(0, 0);
    O1.findMax(0.0f, 0.0f);
    O1.findMax(0, 0, 0);
    O1.findMax(0, 0.0f);
    
    return 0;
}

